package com.project.jnresto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
