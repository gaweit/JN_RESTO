<?php

	//Define your host here.
	$HostName = "localhost";
	 
	//Define your MySQL Database Name here.
	$DatabaseName = "jnorder";
	 
	//Define your Database UserName here.
	$HostUser = "root";
	 
	//Define your Database Password here.
	$HostPass = ""; 

?>