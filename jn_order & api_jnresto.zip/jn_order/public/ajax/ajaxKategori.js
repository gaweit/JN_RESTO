var table;
var save_method;
var url;

$(document).ready(function () {
    table = $('#mytable').DataTable({
        "pageLength": 10,
        "autoWidth": true,
        "lengthChange": false,
        "ordering": false,
        "processing": true,
        "searching": true,
        "serverSide": true,
        "deferRender" : true,
        "ajax":{
            "url": urlList,
            "type": "GET"
        }
    });
});

function reload_table() {
    table.ajax.reload(null, false);
}

function show() {
    save_method = 'save';

    $('#modal-form form')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal-form').modal('show');
    $('.modal-title').text('Tambah Produk');

    $('.img=preview').attr('src', urlImgDefault);
}

function ajaxSave() {
    $('#btn-save').text('proses...');
    $('#btn-save').attr('disabled', true);

    if (save_method == 'save') {
        url = urlSave;
    } else {
        url = urlUpdate;
    }

    $.ajax({
        url: url,
        type: "POST",
        data: new FormData($('#form')[0]),
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function (data) {
            if (data.status) {
                $('#modal-form').modal('hide');
                success('Data Berhasil Disimpan.');
                reload_table();
            } else {
                for (let i = 0; i < data.inputerror.length; i++) {
                    $('[name="' + data.inputerror[i] + '"]').parent().parent().addClass('has-error');    
                    $('[name="' + data.inputerror[i] + '"]').next().text(data.error_string[i]);    
                }
            }
            $('#btn-save').text('Simpan');
            $('#btn-save').attr('disabled', false);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            error(errorThrown);

            $('#btn-save').text('Simpan');
            $('#btn-save').attr('disabled', false);
        }
    });
}

function ajaxEdit($id_kategori) 
{
    save_method = 'edit';

    $('#modal-form form')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();

    $.ajax({
        url: urlEdit + $id_kategori,
        type: "GET",
        dataType: "JSON",
        success: function (data) {
            $('[name="id_kategori"]').val(data.id_kategori);
            $('[name="nama_kategori"]').val(data.nama_kategori);
            $('#modal-form').modal('show');
            $('.modal-title').text('Edit Kategori');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            error(errorThrown);
        }
    });
}

function ajaxDelete($id_kategori) {
    if (confirm('Apakah yakin menghapus data ini ?')) {
        $.ajax({
            url: urlDelete + $id_kategori,
            type: "GET",
            dataType: "JSON",
            success: function (data) {
                if (data.status) {
                    success('Data berhasil dihapus.');
                    reload_table();
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                error(errorThrown);
            }
        });
    }
}

function ajaxStatus($id_kategori) {
    if (confirm('Apakah status data ini diubah ?')) {
        $.ajax({
            url: urlStatus + $id_kategori,
            type: "GET",
            dataType: "JSON",
            success: function (data) {
                if (data.status) {
                    success('Data berhasil diubah.');
                    reload_table();
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                error(errorThrown);
            }
        });
    }
}