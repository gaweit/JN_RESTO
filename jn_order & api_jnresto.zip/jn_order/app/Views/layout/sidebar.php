<aside class="main-sidebar">
    <section class="sidebar">

        <ul class="sidebar-menu">

            <li class="<?= ($halaman == 'dashboard') ? 'active' : ''; ?>">
                <a href="<?= site_url('dashboard'); ?>">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="<?= ($halaman == 'kategori') ? 'active' : ''; ?>">
                <a href="<?= site_url('kategori'); ?>">
                    <i class="fa fa-cubes"></i>
                    <span>Kategori</span>
                </a>
            </li>
            <li class="<?= ($halaman == 'produk') ? 'active' : ''; ?>">
                <a href="<?= site_url('produk'); ?>">
                    <i class="fa fa-cube"></i>
                    <span>Produk</span>
                </a>
            </li>
            <li class="<?= ($halaman == 'pelanggan') ? 'active' : ''; ?>">
                <a href="<?= site_url('pelanggan'); ?>">
                    <i class="fa fa-user"></i>
                    <span>Pelanggan</span>
                </a>
            </li>
            <li class="<?= ($halaman == 'pesanan') ? 'active' : ''; ?>">
                <a href="<?= site_url('pesanan'); ?>">
                    <i class="fa fa-exchange"></i>
                    <span>Pesanan</span>
                </a>
            </li>
            <li class="<?= ($halaman == 'laporan') ? 'active' : ''; ?>">
                <a href="<?= site_url('laporan'); ?>">
                    <i class="fa fa-file"></i>
                    <span>Laporan</span>
                </a>
            </li>
        </ul>
    </section>
</aside>