<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Admin\ProdukModel;

class Produk extends BaseController
{
    protected $halaman;
    protected $title;
    protected $produk;
    protected $primaryKey;

    public function __construct()
    {
        $this->halaman      = 'produk';
        $this->title        = 'produk';
        $this->produk       = new ProdukModel();
        $this->primaryKey   = 'id_produk';
    }

    public function index()
    {
        $data = [
            'halaman'   => $this->halaman,
            'title'     => $this->title,
            'main'      => 'produk/index'
        ];
        return view('layout/template', $data);
    }

    public function ajaxList()
    {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']['value'];

        $total = $this->produk->ajaxGetTotal();
        $output = [
            'draw'              => $draw,
            'length'            => $length,
            'recordsTotal'      => $total,
            'recordsFiltered'   => $total
        ];

        if ($search !== '') {
            $list = $this->produk->ajaxGetDataSearch($search, $length, $start);
        } else {
            $list = $this->produk->ajaxGetData($length, $start);
        }

        if ($search !== '') {
            $total_search = $this->produk->ajaxGetTotalSearch($search);
            $output = [
                'recordsTotal'      => $total_search,
                'recordsFiltered'   => $total_search
            ];
        }

        $data   = [];
        $no     = $start + 1;
        foreach ($list as $temp) {
            $aksi = '
                <div class="text-center">
                    <a href="javascript:void(0)" class="btn btn-warning btn-sm" data-toggle="tooltip" title="Edit Data" onclick="ajaxEdit(' . $temp['id_produk'] . ')">
                        <i class="fa fa-pencil"></i>
                    </a>
                    <a href="javascript:void(0)" class="btn btn-danger btn-sm" data-toggle="tooltip" title="Hapus Data" onclick="ajaxDelete(' . $temp['id_produk'] . ')">
                        <i class="fa fa-trash"></i>
                    </a>
                </div>
            ';

            $status = '
                <div class="text-center">
                    <a href="javascript:void(0)" data-toggle="tooltip" title="' . ($temp['status'] == '0' ? 'Aktifkan' : 'Non-aktifkan') . '" onclick="ajaxStatus(' . $temp['id_produk'] . ')">
                        ' . formatStatus($temp['status']);
            '
                    </a>
                </div>
            ';

            $gambar = '
                <div class="text-center">
                    <img src="' . base_url('/uploads/img/' . $temp['gambar']) . '" alt="' . $temp['gambar'] . '" width="200px" height="125px">
                </div>
            ';

            $row = [];
            $row[] = $no++;
            $row[] = $gambar;
            $row[] = $temp['nama_produk'];
            $row[] = $temp['harga'];
            $row[] = $temp['kategori'];
            $row[] = $temp['deskripsi'];
            $row[] = $status;
            $row[] = $aksi;

            $data[] = $row;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajaxEdit($id_produk)
    {
        $produk = $this->produk->find($id_produk);
        echo json_encode($produk);
    }

    public function ajaxSave()
    {
        $this->_validate('save');
        $data = [
            'nama_produk'   => $this->request->getVar('nama_produk'),
            'harga'         => $this->request->getVar('harga'),
            'deskripsi'     => $this->request->getVar('deskripsi'),
            'gambar'        => uploadImage($this->request->getFile('gambar')),
            'kategori'      => $this->request->getVar('kategori'),
        ];

        if ($this->produk->save($data)) {
            echo json_encode(['status' => TRUE]);
        } else {
            echo json_encode(['status' => FALSE]);
        }
    }

    public function ajaxUpdate()
    {
        $this->_validate('update');

        $id_produk  = $this->request->getVar('id_produk');
        $produk     = $this->produk->find($id_produk);
        if ($this->request->getFile('gambar') == '') {
            $gambar = $produk['gambar'];
        } else {
            unlink('uploads/img/' . $produk['gambar']);
            $gambar = uploadImage($this->request->getFile('gambar'));
        }

        $data = [
            'id_produk'     => $id_produk,
            'nama_produk'   => $this->request->getVar('nama_produk'),
            'harga'         => $this->request->getVar('harga'),
            'deskripsi'     => $this->request->getVar('deskripsi'),
            'gambar'        => $gambar,
            'kategori'      => $this->request->getVar('kategori'),
            'status'        => '1'
        ];

        if ($this->produk->save($data)) {
            echo json_encode(['status' => TRUE]);
        } else {
            echo json_encode(['status' => FALSE]);
        }
    }

    public function ajaxDelete($id_produk)
    {
        $produk     = $this->produk->find($id_produk);
        unlink('uploads/img/' . $produk['gambar']);
        if ($this->produk->delete($id_produk)) {
            echo json_encode(['status' => TRUE]);
        } else {
            echo json_encode(['status' => FALSE]);
        }
    }


    public function ajaxStatus($id_produk)
    {
        $produk = $this->produk->find($id_produk);
        $data['id_produk'] = $id_produk;

        if ($produk['status'] == '0') {
            $data['status'] = '1';
        } else {
            $data['status'] = '0';
        }

        if ($this->produk->save($data)) {
            echo json_encode(['status' => TRUE]);
        } else {
            echo json_encode(['status' => FALSE]);
        }
    }

    public function _validate($method)
    {
        if (!$this->validate($this->produk->getRulesValidation($method))) {
            $validation = \Config\Services::validation();

            $data = [];
            $data['error_string']   = [];
            $data['inputerror']     = [];
            $data['status']         = TRUE;

            if ($validation->hasError('nama_produk')) {
                $data['inputerror'][]   = 'nama_produk';
                $data['error_string'][] = $validation->getError('nama_produk');
                $data['status'] = FALSE;
            }

            if ($validation->hasError('harga')) {
                $data['inputerror'][]   = 'harga';
                $data['error_string'][] = $validation->getError('harga');
                $data['status'] = FALSE;
            }

            if ($validation->hasError('deskripsi')) {
                $data['inputerror'][]   = 'deskripsi';
                $data['error_string'][] = $validation->getError('deskripsi');
                $data['status'] = FALSE;
            }

            if ($validation->hasError('kategori')) {
                $data['inputerror'][]   = 'kategori';
                $data['error_string'][] = $validation->getError('kategori');
                $data['status'] = FALSE;
            }

            if ($validation->hasError('gambar')) {
                $data['inputerror'][]   = 'gambar';
                $data['error_string'][] = $validation->getError('gambar');
                $data['status'] = FALSE;
            }

            if ($data['status'] == FALSE) {
                echo json_encode($data);
                exit();
            }
        }
    }
}
