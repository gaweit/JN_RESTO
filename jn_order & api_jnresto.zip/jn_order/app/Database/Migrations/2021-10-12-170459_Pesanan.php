<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Pesanan extends Migration
{
    public function up()
    {

        $this->forge->addfield([
            'id_pesanan' => [
                'type'          => 'VARCHAR',
                'constraint'    => 11,
            ],
            'tgl' => [
                'type'          => 'DATETIME',

            ],
            'total_bayar' => [
                'type'          => 'INT',
                'constraint'    => 10,
            ],
            'id_pelanggan' => [
                'type'          => 'INT',
                'costraint'     => 11,
                'unsigned'  => TRUE,
            ],
            'status' => [
                'type' => 'ENUM',
                'constraint' => ['0', '1', '2', '3'],
            ],
        ]);
        $this->forge->addKey('id_pesanan', TRUE);
        $this->forge->addForeignKey('id_pelanggan', 'pelanggan', 'id_pelanggan');
        $this->forge->createTable('pesanan');
    }

    public function down()
    {
        $this->forge->dropTable('pesanan');
    }
}
