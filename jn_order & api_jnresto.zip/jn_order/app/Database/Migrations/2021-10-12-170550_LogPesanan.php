<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class LogPesanan extends Migration
{
    public function up()
    {

        $this->forge->addfield([
            'id_logpesanan' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'nama_produk' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'harga' => [
                'type' => 'INT',
                'constraint' => 10,
            ],
            'qty' => [
                'type' => 'INT',
                'constraint' => 10,
            ],
            'total' => [
                'type' => 'INT',
                'constraint' => 10,
            ],
            'id_pesanan' => [
                'type' => 'VARCHAR',
                'constraint' => 11,
            ],
            'id_pelanggan' => [
                'type' => 'INT',
                'costraint' => 11,
                'unsigned' => TRUE,
            ],
            'status' => [
                'type' => 'ENUM',
                'constraint' => ['0', '1', '2', '3'],
            ],
        ]);
        $this->forge->addKey('id_logpesanan', TRUE);
        $this->forge->addForeignKey('id_pesanan', 'pesanan', 'id_pesanan');
        $this->forge->addForeignKey('id_pelanggan', 'pelanggan', 'id_pelanggan');
        $this->forge->createTable('logpesanan');
    }

    public function down()
    {
        $this->forge->dropTable('logpesanan');
    }
}
