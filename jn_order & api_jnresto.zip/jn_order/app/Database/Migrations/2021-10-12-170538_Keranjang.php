<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Keranjang extends Migration
{
    public function up()
    {
        $this->forge->addfield([
            'id_keranjang' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'nama_produk' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'harga' => [
                'type' => 'INT',
                'constraint' => 10,
            ],
            'qty' => [
                'type' => 'INT',
                'constraint' => 10,
            ],
            'total' => [
                'type' => 'INT',
                'constraint' => 10,
            ],
            'gambar' => [
                'type' => 'TEXT',
            ],
            'expired' => [
                'type' => 'INT',
                'constraint' => 10,
            ],
            'id_pelanggan' => [
                'type' => 'INT',
                'costraint' => 11,
                'unsigned' => TRUE,
            ],
        ]);
        $this->forge->addKey('id_keranjang', TRUE);
        $this->forge->addForeignKey('id_pelanggan', 'pelanggan', 'id_pelanggan', 'CASCADE', 'CASCADE');
        $this->forge->createTable('keranjang');
    }

    public function down()
    {
        $this->forge->dropTable('keranjang');
    }
}
