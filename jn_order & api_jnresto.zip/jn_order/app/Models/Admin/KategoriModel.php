<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class KategoriModel extends Model
{
    protected $table            = 'kategori';
    protected $primaryKey       = 'id_kategori';
    protected $allowedFields    = ['nama_kategori', 'status'];


    public function getRulesValidation($method)
    {
        $rulesValidation = [
            'nama_kategori' => [
                'label'     => 'Nama Kategori',
                'rules'     => 'required',
                'errors'    => [
                    'required' => '{field} harus diisi.'
                ]
            ]
        ];
        return $rulesValidation;
    }

    public function ajaxGetData($length, $start)
    {
        $result = $this->orderBy('id_kategori', 'desc')
            ->findAll($length, $start);

        return $result;
    }
    function getapi(){
         $result = $this->orderBy('id_kategori', 'desc')
            ->findAll();
    }

    public function ajaxGetDataSearch($search, $length, $start)
    {
        $result = $this->like('nama_kategori', $search)
            ->orderBy('id_kategori', 'desc')
            ->findAll($length, $start);
        return $result;
    }

    public function ajaxGetTotal()
    {
        $result = $this->countAll();

        if (isset($result)) {
            return $result;
        }
        return 0;
    }

    public function ajaxGetTotalSearch($search)
    {
        $result = $this->like('nama_kategori', $search)
            ->countAllResults();
        return $result;
    }
}
